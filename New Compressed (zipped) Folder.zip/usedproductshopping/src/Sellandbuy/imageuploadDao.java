package Sellandbuy;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import shopping.ConnectionManager;

public class imageuploadDao {
	
public static void imageupload(int pid,String image)
{   
	Connection con = null;
	PreparedStatement stmt = null;
	String query = "insert into images(productId, image) values(?, ?)";
	con = ConnectionManager.getConnection();
	try{
		stmt = con.prepareStatement(query);
		stmt.setInt(1,pid);
		stmt.setString(2, image);
		
		stmt.executeUpdate();
		System.out.println("uploaded");
	}
	catch(SQLException e){
		e.printStackTrace();
	}	
}

public static String getImage(int pid)
{   
	Connection con = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	String image = null;
	String query = "select image from images where productid=?";
	con = ConnectionManager.getConnection();
	try{
		stmt = con.prepareStatement(query);
		stmt.setInt(1,pid);
		
		rs = stmt.executeQuery();
		while(rs.next()){
			image = rs.getString(1);
		}
	}
	catch(SQLException e){
		e.printStackTrace();
	}	
	return image;
}
}
