package Sellandbuy;

public class orderBean {
private int pid;
private String pname;
private float price;
private int cid;
private String kind;
private int usage;
private int sellerid;
private String image;
public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}
public int getSellerid() {
	return sellerid;
}
public void setSellerid(int sellerid) {
	this.sellerid = sellerid;
}
public String getKind() {
	return kind;
}
public void setKind(String kind) {
	this.kind = kind;
}
public int getUsage() {
	return usage;
}
public void setUsage(int usage) {
	this.usage = usage;
}
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
}
