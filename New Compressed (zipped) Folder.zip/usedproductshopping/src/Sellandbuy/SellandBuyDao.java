package Sellandbuy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import shopping.ConnectionManager;

import com.product.ProductBean;

public class SellandBuyDao {
	public String addProduct(int pid, String name, float price, String kind,
			int usage, int sellerid) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;

		int a = 0;
		boolean flag=false;
		ResultSet rs=null;
		String str = "insert into product values(?,?,?,?,?,?)";
		String str1="select * from orders where productid=?";
		try {
			stmt = conn.prepareStatement(str);
			stmt.setInt(1, pid);
			stmt.setString(2, name);
			stmt.setFloat(3, price);
			stmt.setString(4, kind);
			stmt.setInt(5, usage);
			stmt.setInt(6, sellerid);
			a = stmt.executeUpdate();
			stmt=conn.prepareStatement(str1);
			stmt.setInt(1, pid);
			rs=stmt.executeQuery();
			flag=rs.next();
			
			

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			try {

				if (stmt != null)

					stmt.close();

				conn.commit();

				if (conn != null)

					conn.close();

			} catch (SQLException e) {

				// TODO Auto-generated catch block

				e.printStackTrace();

			}
		}
if(a==1&&flag==false)
		return Integer.toString(a);
else
	return "no";
	}

	public void buyProduct(int pid, int cid) {
		Connection con = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List<ProductBean> holdingsList = new ArrayList<>();

		String str1 = "insert into orders values(?,?,?,?,?,?,?)";
		String str = "delete from product where productid=?";

		String str2 = "select * from product where productid=?";
		ResultSet resultset = null;
		try {
			holdingsList = new ArrayList<ProductBean>();
			stmt = con.prepareStatement(str2);
			stmt.setInt(1, pid);
			resultset = stmt.executeQuery();

			while (resultset.next()) {
				ProductBean B = new ProductBean();

				B.setProductid(resultset.getInt(1));
				B.setName(resultset.getString(2));
				B.setPrice(resultset.getFloat(3));
				B.setKind(resultset.getString(4));
				B.setUsage(resultset.getInt(5));
				B.setSellerid(resultset.getInt(6));
				holdingsList.add(B);
			}
			Iterator<ProductBean> itr = holdingsList.iterator();

			ProductBean Bean1 = itr.next();
			stmt = con.prepareStatement(str1);
			stmt.setInt(1, Bean1.getProductid());
			stmt.setString(2, Bean1.getName());
			stmt.setFloat(3, Bean1.getPrice());
			stmt.setInt(4, cid);
			stmt.setString(5, Bean1.getKind());
			stmt.setInt(6, Bean1.getUsage());
			stmt.setInt(7, Bean1.getSellerid());
			stmt.executeUpdate();
			stmt = con.prepareStatement(str);
			stmt.setInt(1, pid);
			stmt.executeUpdate();
			System.out
					.println("your selected product is successfully added to your orderlist");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			try {

				if (resultset != null)

					resultset.close();

				if (stmt != null)

					stmt.close();

				con.commit();

				if (con != null)

					con.close();

			} catch (SQLException e) {

				// TODO Auto-generated catch block

				e.printStackTrace();

			}
		}

		// TODO Auto-generated method stub

	}

	public void orders(int cid) {

		Scanner sc = new Scanner(System.in);
		Connection con = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		List<orderBean> holdingsList = new ArrayList<>();
		boolean choice = false;
		do {
			System.out.println("1)View order\n2)cancel order");

			int a = sc.nextInt();
			int pid;

			switch (a) {

			case 1:

				float sum = 0;

				ResultSet resultset = null;
				String strr = "select * from orders where customer_id=?";
				try {
					stmt = con.prepareStatement(strr);
					stmt.setInt(1, cid);
					resultset = stmt.executeQuery();
					while (resultset.next()) {
						orderBean B = new orderBean();

						B.setPid(resultset.getInt(1));
						B.setPname(resultset.getString(2));
						B.setPrice(resultset.getFloat(3));
						B.setCid(resultset.getInt(4));

						sum += B.getPrice();
						holdingsList.add(B);
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}

				System.out.printf("%-20s %-20s %-20s %-20s \n", "Productid",
						"ProductName", "ProductPrice", "CustomerId");
				Iterator<orderBean> itr = holdingsList.iterator();
				while (itr.hasNext()) {
					orderBean B1 = itr.next();
					System.out.printf("%-20d %-20s %-20f %-20d \n",
							B1.getPid(), B1.getPname(), B1.getPrice(),
							B1.getCid());
				}
				System.out.println("Your total price is :" + sum);
				// TODO Auto-generated method stub
				break;
			case 2:
				System.out.println("enter the productid you want remove");
				pid = sc.nextInt();
				String str1 = "insert into product values(?,?,?,?,?)";
				String str = "delete from orders where productid=?";
				String str2 = "select * from orders where productid=? and customer_id=?";

				try {
					stmt = con.prepareStatement(str2);
					stmt.setInt(1, pid);
					stmt.setInt(2, cid);
					holdingsList = new ArrayList<orderBean>();

					resultset = stmt.executeQuery();
					while (resultset.next()) {
						orderBean B = new orderBean();

						B.setPid(resultset.getInt(1));
						B.setPname(resultset.getString(2));
						B.setPrice(resultset.getFloat(3));
						B.setKind(resultset.getString(5));
						B.setUsage(resultset.getInt(6));
						holdingsList.add(B);
					}
					Iterator<orderBean> itr1 = holdingsList.iterator();
					orderBean Bean1w = itr1.next();
					stmt = con.prepareStatement(str1);
					stmt.setInt(1, Bean1w.getPid());
					stmt.setString(2, Bean1w.getPname());
					stmt.setFloat(3, Bean1w.getPrice());
					stmt.setString(4, Bean1w.getKind());
					stmt.setInt(5, Bean1w.getUsage());
					stmt.executeUpdate();
					stmt = con.prepareStatement(str);
					stmt.setInt(1, pid);
					stmt.executeUpdate();
					System.out
							.println("your selected product is successfully removed from orderlist");
				}

				catch (SQLException e)

				{
					e.printStackTrace();
				}

				break;
			default:
				System.out.println("enter the correct option");
				choice = true;
			}
		} while (choice);
	}
}
