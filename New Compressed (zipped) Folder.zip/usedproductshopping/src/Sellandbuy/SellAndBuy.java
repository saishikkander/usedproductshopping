package Sellandbuy;
import java.sql.SQLException;
import java.util.*;

import com.product.*;

public class SellAndBuy {
public  void sellbuyview(int login) 
{
	Scanner s=new Scanner(System.in);
	int pid,usage,cid;
	float price;
	boolean flag=false;
	String name,kind;
	List<ProductBean> holdingList = new ArrayList<>();
	do
	{
		flag=false;
	System.out.println("Welcome\n1)Sell Product\n2)Buy product\n3)View Orders");
	int n=s.nextInt();
	
		switch(n)
		{
		
		case 1:
			SellandBuyDao sb=new SellandBuyDao();
			System.out.println("Enter any productid");
		pid=s.nextInt();
		System.out.println("Enter the productname");
		s.nextLine();
		name=s.nextLine();
		System.out.println("Enter the productprice");
		price=s.nextFloat();
		System.out.println("Enter the productkind");
		s.nextLine();
		kind=s.nextLine();
		System.out.println("Enter the product usage period");
		usage=s.nextInt();
		
		String str1 = sb.addProduct(pid,name,price,kind,usage,login);
		System.out.println(str1);
		break;
		case 2:
			SelectOption select=new SelectOption();
			SellandBuyDao sb1=new SellandBuyDao();
			select.show(login);
			System.out.println("enter the productid you want to buy");
			pid=s.nextInt();
			cid=login;
			sb1.buyProduct(pid,cid);
			break;
		case 3:
			SellandBuyDao order=new SellandBuyDao();
			cid=login;
			 order.orders(cid);
			break;
			 
			default:System.out.println("enter the correct option");
			flag=true;
			
			
		
		}
		}while(flag);
	
}}

