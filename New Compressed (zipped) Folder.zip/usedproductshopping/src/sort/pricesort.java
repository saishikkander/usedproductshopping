package sort;

import java.util.Comparator;

import com.product.ProductBean;

public class pricesort implements Comparator{
	public int compare(Object o1, Object o2) {
		ProductBean s1=(ProductBean) o1;
				ProductBean s2=(ProductBean) o2;
		// TODO Auto-generated method stub
				if(s1.getPrice()==s2.getPrice())  
					return 0;  
					else if(s1.getPrice()>s2.getPrice())  
					return 1;  
					else  
					return -1; 

}}
