package sort;
import java.util.Comparator;

import com.product.*;

public class namesort implements Comparator{
	  
		

		public int compare(Object o1, Object o2) {
			ProductBean s1=(ProductBean) o1;
					ProductBean s2=(ProductBean) o2;
			// TODO Auto-generated method stub
					return s1.getName().compareTo(s2.getName());  
		}

		
		}


