
package shopping;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import shopping.ConnectionManager;

public class userDao {
	public List getHoldings(int id,int productid,int productidd){
		
		//step 3: create statement object 
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		Statement stmt1=null;
		List holdingsList = null;
		String searchstring="select * from customer where userid = ?";
		String searchstring1="update customer set userid=1 where userid=2";
		String Searchstring2="delete from  customer where productid="+productidd;
		String searchstring3="insert into customer values(1,'sai',127,60)";
		 ResultSet resultset=null;	
		try {
			stmt1 = conn.createStatement();
			
	
			
			 stmt1.executeUpdate(searchstring3);	

			 stmt1= conn.createStatement();
			 
			  stmt1.executeUpdate(searchstring1);
			  System.out.println("updated success fully");
			
				
			
	
			
		  stmt1.executeUpdate(Searchstring2);
			stmt = conn.prepareStatement(searchstring);
			stmt.setInt(1,id);
		resultset = stmt.executeQuery();
			
			 holdingsList = new ArrayList<userBean>();
			while(resultset.next()) {
				userBean userBean = new userBean();
				userBean.setproductId(resultset.getInt(3));
				userBean.setuserName(resultset.getString(2));
				userBean.setProductrate(resultset.getInt(4));
				holdingsList.add(userBean);
						
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		
		
		return holdingsList;
			
	}
	
	
	
	
	
	
	
	
	
	
	
}
