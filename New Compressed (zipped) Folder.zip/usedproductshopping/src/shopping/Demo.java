package shopping;

import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo {

	public static void main(String[] args) {
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        
    	
        try {
			con = DriverManager.getConnection("jdbc:derby://172.24.18.66:1527/usedproductdetails","user","pwd");
			System.out.println("executed");
			
			String searchstring1="update customer set userid=2";
			Statement st=con.createStatement();
		st.executeUpdate(searchstring1);
			System.out.println("executed");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         								
    

	}

}
