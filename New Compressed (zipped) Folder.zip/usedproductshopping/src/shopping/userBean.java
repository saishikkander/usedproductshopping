
package shopping;
public class userBean {
	
    private String userId ;
    private String userName ;
 private int productId;
 private int productrate;
	public int getProductrate() {
	return productrate;
}
public void setProductrate(int productrate) {
	this.productrate = productrate;
}
	/*public userBean(String userId,String  userName, String password){
    	this.userId = userId;
    	this.userName = userName;
this.password=password;
    	
    }*/
	public String getuserId() {
		return userId;
	}
	public void setuserId(String userId) {
		this.userId = userId;
	}
	public String getuserName() {
		return userName;
	}
	public void setuserName(String userName) {
		this.userName = userName;
	}
    public int getproductId() {
		return productId;
	}
	public void setproductId(int productId) {
		this.productId = productId;
	}
}