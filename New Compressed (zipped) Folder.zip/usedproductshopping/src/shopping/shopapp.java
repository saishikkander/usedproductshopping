package shopping;



import java.util.Iterator;
import java.util.List;

public class shopapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int userId = 1;
		int productid=20;
		int productidd=13;
		userDao userDao = new userDao();
		@SuppressWarnings("unchecked")
		List<userBean> holdingList = userDao.getHoldings(userId,productid,productidd);
		 Iterator<userBean> itr =  holdingList.iterator();
		while(itr.hasNext()){
			userBean userBean = itr.next();
			System.out.println(userBean.getproductId()+ " "+ userBean.getuserName()+" "+userBean.getProductrate());
		}

	}

}
