package com.servletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import user_login.loginDao;

@SuppressWarnings("serial")
public class loginValidator extends HttpServlet{

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
	
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	          
	   String n=request.getParameter("username");  
	    String p=request.getParameter("userpass"); 
	   int no=Integer.parseInt(n);
	  
	    loginDao l=new loginDao();
	  
boolean swi=false;
swi=l.signin(no,p);
if(swi==false)
	{
	 Cookie ck=new Cookie("name",n); 
     ck.setMaxAge(12);
     response.addCookie(ck);  
	RequestDispatcher rd=request.getRequestDispatcher("sellandbuy.html");  
	rd.forward(request, response);  

}  
else{  
out.print("Sorry UserName or Password Error!");  
RequestDispatcher rd=request.getRequestDispatcher("login.html");  
rd.include(request, response);
  }
	
	    /*ServletConfig config=getServletConfig();
	    //read from servlet config
	    String validPass = config.getInitParameter("password");
	    System.out.println("validPass : "+ validPass);
	    
	    // read from servlet context    
	    ServletContext context=getServletContext();  
	    String  connectURL = context.getInitParameter("connection-url");
	    System.out.println("connectURL :"+ connectURL);
	    //set attribute
	    context.setAttribute("companyName", "iNautix");
	    System.out.println("CompanyName :"+context.getAttribute("companyName"));*/
	    
	   /* if(p.equals("servlet")){  
	        RequestDispatcher rd=request.getRequestDispatcher("sellandbuy.html");  
	        rd.forward(request, response);  
	    }  
	    else{  
	        out.print("Sorry UserName or Password Error!");  
	        RequestDispatcher rd=request.getRequestDispatcher("/dispatcher.html");  
	        rd.include(request, response);  
	                      
	        }  */
	    }  
}
