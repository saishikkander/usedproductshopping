package com.servletController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import user_login.loginDao;

@SuppressWarnings("serial")
public class registerValidate extends HttpServlet{

	

	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException { 
		PrintWriter out = response.getWriter(); 
		response.setContentType("text/html"); 
		String user=request.getParameter("userid");
		if(user!=null)
		{

		try{
			
			int userid=Integer.parseInt(user);
			 String p=request.getParameter("password"); 
			    String address=request.getParameter("address");
			    String email=request.getParameter("emailid");
			   
			    String phone=request.getParameter("phoneno");
			    
			  
			    loginDao l=new loginDao();
			  
		boolean swi=false;
		       swi=l.register(userid,p,email,address,phone);
		if(swi==false)
			{
			out.print("<script> type=\"text/javascript\">");
			out.print("alert('Registered Successfully');");
			out.print("location='login.jsp';");
			out.print("</script>");
			//RequestDispatcher rd=request.getRequestDispatcher("login.html");  
			//rd.forward(request, response);  

		}  
		else{  
		out.print("<script> type=\"text/javascript\">");
		out.print("alert('userid exist');");
		out.print("location='register.html';");
		out.print("</script>");
		}
//			response.sendRedirect("registerValidate");
			/*out.print("<script> type=\"text/javascript\">");
			out.print("alert('Do you want to register');");
			out.print("location='registerValidate';");
			out.print("</script>");*/
			
		}
		catch(Exception e)
		{
			out.print("<script> type=\"text/javascript\">");
			out.print("alert('Enter a Number as UserId');");
			out.print("location='register.html';");
			out.print("</script>");
					
		}}
	  
	    
	   
	          
	 //  String n=request.getParameter("userid");  
	    
	
	    /*ServletConfig config=getServletConfig();
	    //read from servlet config
	    String validPass = config.getInitParameter("password");
	    System.out.println("validPass : "+ validPass);
	    
	    // read from servlet context    
	    ServletContext context=getServletContext();  
	    String  connectURL = context.getInitParameter("connection-url");
	    System.out.println("connectURL :"+ connectURL);
	    //set attribute
	    context.setAttribute("companyName", "iNautix");
	    System.out.println("CompanyName :"+context.getAttribute("companyName"));*/
	    
	   /* if(p.equals("servlet")){  
	        RequestDispatcher rd=request.getRequestDispatcher("sellandbuy.html");  
	        rd.forward(request, response);  
	    }  
	    else{  
	        out.print("Sorry UserName or Password Error!");  
	        RequestDispatcher rd=request.getRequestDispatcher("/dispatcher.html");  
	        rd.include(request, response);  
	                      
	        }  */
	    }  
}
