package com.product;
import java.io.*;
import java.util.*;

import shopping.*;

public class SelectOption {
	 public void show(int login)
	{
		String pname;
		
		boolean choice=false;
		boolean no=false;
		Scanner s=new Scanner(System.in);
		List<ProductBean> holdingList = new ArrayList<>();
		do
		{
		System.out.println("1)Display products\n2)Search for Product");
		int n=s.nextInt();
		String yesno;
		
		
		
		switch(n)
		{
		case 1:{
			DisplayProductDao obj=new DisplayProductDao();	
			 holdingList=obj.Display(login);
			 Iterator<ProductBean> itr =  holdingList.iterator();
			 System.out.printf("%-20s %-20s %-20s %-20s %-20s\n","ID","NAME","PRICE","KIND","USAGE IN MONTH");
			 while(itr.hasNext()){
					ProductBean Bean = itr.next();
					System.out.printf("%-20d %-20s %-20f %-20s %-20d\n",Bean.getProductid(),Bean.getName(),Bean.getPrice(),Bean.getKind(),Bean.getUsage());}
			 /*System.out.println("Do You want to continue");
			 s.nextLine();
			 yesno=s.nextLine();
			 if(yesno.equalsIgnoreCase("yes"))
				 choice=true;*/
			 break;
		}
	    case 2:{
	    	s.nextLine();
	    	DisplayProductDao obj1=new DisplayProductDao();
	    	do{
	    		no=false;
	    	
				 System.out.println("Enter a productName");
				 pname=s.nextLine();
				
			holdingList=obj1.search(pname,login);
			if(holdingList!=null)
			{
				Iterator<ProductBean> itr =  holdingList.iterator();
				 System.out.printf("%-20s %-20s %-20s %-20s %-20s\n","ID","NAME","PRICE","KIND","USAGE IN MONTH");
			
				 while(itr.hasNext()){
					
						ProductBean Bean = itr.next();
						System.out.printf("%-20d %-20s %-20f %-20s %-20d\n",Bean.getProductid(),Bean.getName(),Bean.getPrice(),Bean.getKind(),Bean.getUsage());}
			 }
			 else
			 {no=true;
			 
			 }
			 
	    	}while(no);
				/* System.out.println("Do You want to continue");
				 
				 yesno=s.nextLine();
				 if(yesno.equalsIgnoreCase("yes"))
					 choice=false;*/
				 break;
	    }
	    
		default: 
					 System.out.println("enter correct value");
				 	choice=true;	 
			

}}while(choice);
		}}
