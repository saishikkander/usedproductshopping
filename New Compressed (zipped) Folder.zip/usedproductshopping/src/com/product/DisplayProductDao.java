package com.product;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import org.apache.derby.client.am.SqlException;

import shopping.*;
import Sellandbuy.*;

public class DisplayProductDao {
	final Logger logger=Logger.getLogger(DisplayProductDao.class.getName());

public	List Display(int cid)
	{
		Connection con=ConnectionManager.getConnection();
		System.out.println("List of products");
		//PreparedStatement stmt = null;
		PreparedStatement stmt1=null;
		List holdingsList = null;
		String display="select * from product where seller_id !=? order by productid";
				ResultSet resultset=null;
				ResultSet rs=null;
				logger.info("successsssss");
		try{
			stmt1=con.prepareStatement(display);
			stmt1.setInt(1,cid);
			resultset = stmt1.executeQuery();
			holdingsList = new ArrayList<ProductBean>();
			while(resultset.next()) {
				ProductBean B = new ProductBean();
				
				B.setProductid(resultset.getInt(1));
				B.setName(resultset.getString(2));
				B.setPrice(resultset.getFloat(3));
				B.setKind(resultset.getString(4));
				B.setUsage(resultset.getInt(5));
			//	B.setSellerid(resultset.getInt(6));
				String str1="select images.image from images join product on images.productid=product.productid where product.productid=?";
				stmt1=con.prepareStatement(str1);
				stmt1.setInt(1,resultset.getInt(1));
				rs=stmt1.executeQuery();
				while(rs.next()){
					B.setImage(rs.getString(1));
					logger.info(rs.getString(1));
				}
				
				holdingsList.add(B);
						
			}
			
		}
		catch(Exception e)
		{e.printStackTrace();
		}
		/*finally{

            try {

                    if(resultset != null)

                    resultset.close();

                    if(stmt1 != null)                                        

                    stmt1.close();                           

                    con.commit();

                    if(con != null)

                    con.close();

            }catch (SQLException e) {

                    // TODO Auto-generated catch block

                    e.printStackTrace();

            }}*/


		 
		 return holdingsList;
	}
	public List search(String pname,int cid)
	{
		Connection con=ConnectionManager.getConnection();
		int n=0;
		System.out.println("product details");
		PreparedStatement stmt = null;
		String str="select * from product where kind like ? and seller_id !=? order by productid";
		ResultSet resultset=null;
		ResultSet rs=null;
		List holdingsList=null;
		int pid=0,usage=0;
		String name="",kind="";
		float price=0;
		
		try
		{
			holdingsList =new ArrayList<ProductBean>();
			stmt=con.prepareStatement(str);
			stmt.setString(1, pname+"%");
			stmt.setInt(2,cid);
			resultset=stmt.executeQuery();
			
			/*if(rs.next()==false)
			{
				System.out.println("there is no product");
				return null;
				
			}*/
			
			
			
			/*while(resultset.next()) {
				//ProductBean B = new ProductBean();
				
			pid=resultset.getInt(1);
			name=	resultset.getString(2);
			price=	resultset.getFloat(3);
			kind=	resultset.getString(4);
			usage=	resultset.getInt(5);
				
				//holdingsList.add(B);
				
			}
			if(pid==0)
			{
				System.out.println("there is no product");
				return null;
			}
			else*/
			while(resultset.next()){
				ProductBean B = new ProductBean();
				B.setProductid(resultset.getInt(1));
				B.setName(resultset.getString(2));
				B.setPrice(resultset.getFloat(3));
				B.setKind(resultset.getString(4));
				B.setUsage(resultset.getInt(5));
				B.setSellerid(resultset.getInt(6));
				String str1="select images.image from images join product on images.productid=product.productid where product.productid=?";
				stmt=con.prepareStatement(str1);
				stmt.setInt(1,resultset.getInt(1));
				rs=stmt.executeQuery();
				while(rs.next()){
					B.setImage(rs.getString(1));
					
					
				}
				holdingsList.add(B);
			}
		
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally{

            try {

                    if(resultset != null)

                    resultset.close();

                    if(stmt != null)                                        

                    stmt.close();                           

                    con.commit();

                    if(con != null)

                    con.close();

            }catch (SQLException e) {

                    // TODO Auto-generated catch block

                    e.printStackTrace();

            }}

		Iterator<ProductBean> itr =  holdingsList.iterator();
		 while(itr.hasNext()){
				
				ProductBean Bean = itr.next();
				 n=Bean.getProductid();
		 }
		if(n==0)
			return null;
		else
		return holdingsList;
		
	}
	
	

}
