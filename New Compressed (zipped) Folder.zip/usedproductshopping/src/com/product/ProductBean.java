package com.product;
import shopping.*;
public class ProductBean {
private int productid;
private String name;
private float price;
private String kind;
private int usage;
private int sellerid;
private String image;
public String getImage() {
	return image;
}


public void setImage(String image) {
	this.image = image;
}


public int getSellerid() {
	return sellerid;
}


public int getProductid() {
	return productid;
}
public void setProductid(int productid) {
	this.productid = productid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public String getKind() {
	return kind;
}
public void setKind(String kind) {
	this.kind = kind;
}
public int getUsage() {
	return usage;
}
public void setUsage(int usage) {
	this.usage = usage;
}
public void setSellerid(int sellerid) {
	// TODO Auto-generated method stub
	this.sellerid = sellerid;
	
}



	// TODO Auto-generated method stub
	
}

