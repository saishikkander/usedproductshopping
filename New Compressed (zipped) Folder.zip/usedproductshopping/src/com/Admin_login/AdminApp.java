package com.Admin_login;



import java.sql.SQLException;
import java.util.Scanner;


import Sellandbuy.*;

import com.product.*;


public class AdminApp {
	public static void main(String args[]) 
	{
		String login;
		String password;
		boolean condition=false;
		boolean switc=false;
		Scanner s=new Scanner(System.in);
		AdminDao l=new AdminDao();
		System.out.println("Welcome");
		
		
		System.out.println("login");
		
		do{
		
			System.out.println("Adminname");
			login=s.nextLine();
			System.out.println("password");
			
			password=s.nextLine();
			switc=l.signin(login,password);
			{
				if(switc==true)
				System.out.println("enter the valid Adminname and password");
				else
				{
					SellAndBuy sab=new SellAndBuy();
					sab.sellbuyview(1001);
				}
			}
		}while(switc);}}

	
	

