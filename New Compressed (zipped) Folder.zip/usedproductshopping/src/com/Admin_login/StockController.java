package com.Admin_login;


import shipment.*;
import com.product.*;
import java.util.ArrayList;
import java.util.List;
import Sellandbuy.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;


@RestController
@RequestMapping(value = "/stocks")

public class StockController {
	@Autowired
	TestDaoImpl testDaoimpl;
 
	@RequestMapping(value="/all", method=RequestMethod.GET, produces={ MediaType.APPLICATION_JSON_VALUE})	
	public List<ProductBean> getAllTestDetails() throws Exception
	{System.out.println("hiii");
		
		List<ProductBean> testList=new ArrayList<ProductBean>();
		
			testList = testDaoimpl.getAllTests();
		return testList;
	}

	  @RequestMapping(value = "/product" , method = RequestMethod.GET )
	  public List<ProductBean> getAll() {
    	System.out.println("hi2 success");
		ArrayList<ProductBean> List = new ArrayList<ProductBean>();
		adminviewDao da=new adminviewDao();
		List= da.productlist();
		/*list.add(new StockBean("INFY", "INFOSYS TECHNOLOGIES"));*/
		
    	return List;
      }	
	  
	  
	  @RequestMapping(value = "/order" , method = RequestMethod.GET )
	  public List<orderBean> getAllorder() {
    	System.out.println("hi3 success");
		ArrayList<orderBean> List = new ArrayList<orderBean>();
		adminviewDao da=new adminviewDao();
		List= da.orderlist();
		/*list.add(new StockBean("INFY", "INFOSYS TECHNOLOGIES"));*/
		
    	return List;
      }	
	  @RequestMapping(value = "/ship" , method = RequestMethod.GET )
	  public List<shipmentBean> getAllStocks() {
    	System.out.println("hi success");
		ArrayList<shipmentBean> list = new ArrayList<shipmentBean>();
		adminviewDao da=new adminviewDao();
		list= da.viewship();
		/*list.add(new StockBean("INFY", "INFOSYS TECHNOLOGIES"));*/
		
    	return list;
      }	
}
