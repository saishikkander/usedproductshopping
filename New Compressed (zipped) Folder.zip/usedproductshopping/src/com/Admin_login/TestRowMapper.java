package com.Admin_login;

import java.sql.ResultSet;
import java.sql.SQLException;



import org.springframework.jdbc.core.RowMapper;

import com.product.ProductBean;


public class TestRowMapper implements RowMapper<ProductBean> {
	

	public ProductBean mapRow(ResultSet rs, int rownum) throws SQLException {
		// TODO Auto-generated method stub
		
		ProductBean testObj =new ProductBean();
		testObj.setProductid(rs.getInt(1));
		testObj.setName(rs.getString(2));
		testObj.setPrice(rs.getFloat(3));
		
	//	System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" +rs.getTimestamp(5));
	//	System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" + DateFormatter.getNexenFormatDate(rs.getTimestamp(5)));
		return testObj;
		
		
	}

}
