package com.Admin_login;

import java.sql.Types;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.product.ProductBean;





@Repository
public class TestDaoImpl extends JdbcDaoSupport{

	@Autowired
	public TestDaoImpl(DataSource datasource) {
		// TODO Auto-generated constructor stub
		setDataSource(datasource);
	}

	

	public List<ProductBean> getAllTests() throws Exception {
		// TODO Auto-generated method stub
		List<ProductBean> testList = null;

		testList = getJdbcTemplate().query("select * from product",
				new Object[] {}, new TestRowMapper());

		return testList;
	}}
	

	
	

	
	

