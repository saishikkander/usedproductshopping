package com.Admin_login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import shopping.ConnectionManager;

public class check {
	public static void main(String args[]){
	Connection con=ConnectionManager.getConnection();
	
	String str2="select images.productid from product inner join images on product.productid = images.productid   ";
	ResultSet rs=null;
	PreparedStatement stmt=null;
	
	
	try
	{System.out.println("hi");
		stmt=con.prepareStatement(str2);
		
		rs=stmt.executeQuery();
		System.out.println(rs);
		while(rs.next())
		{
			System.out.println(rs.getString(1));
		
			
		}
		
			
		
	}
	catch(SQLException e)
	{System.out.println("error");
		e.printStackTrace();
	}
}}
