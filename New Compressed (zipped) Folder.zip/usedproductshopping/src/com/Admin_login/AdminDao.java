package com.Admin_login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import shopping.ConnectionManager;

public class AdminDao {
public boolean signin(String aid,String pwd)
{String uid;
int flag=0;
	Connection con=ConnectionManager.getConnection();
	String str="select * from admin_login where name=? and password=?";
	ResultSet resultset=null;
	PreparedStatement stmt=null;
	boolean str1=true;
	try
	{
		stmt=con.prepareStatement(str);
		stmt.setString(1, aid);
		stmt.setString(2, pwd);
		resultset=stmt.executeQuery();
		while(resultset.next())
		{
			uid=resultset.getString(1);
			flag=1;
		}
		if(flag==0)
		{
			
			str1=true;
		}
		else
			str1=false;
		
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	return str1;
}
}
