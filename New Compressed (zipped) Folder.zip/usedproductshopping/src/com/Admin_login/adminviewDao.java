package com.Admin_login;
import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.product.*;

import Sellandbuy.*;
import shopping.*;
import shipment.*;

public class adminviewDao {
	public  ArrayList<shipmentBean> viewship()
	{
		Connection conn =ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
		
		ArrayList<shipmentBean> ob2=new ArrayList<shipmentBean>();
		
		String print="select * from shipment ";
		
		ResultSet resultset=null;

		
		try
		{
			
			stmt=conn.prepareStatement(print);
			
			resultset=stmt.executeQuery();
			while(resultset.next())
			{
				shipmentBean Bean1=new shipmentBean();
				Bean1.setProductid(resultset.getInt(1));
				Bean1.setProductname(resultset.getString(2));
				Bean1.setProductprice(resultset.getFloat(3));
				Bean1.setAddress(resultset.getString(4));
				Bean1.setCustid(resultset.getInt(5));
				
				ob2.add(Bean1);
			}
			
			
			
			
		
		
		
	}
		catch(SQLException e)
	    {
	    	e.printStackTrace();
	    }
		return ob2;
	    
	    
		
		
		
	}
	
	public ArrayList<ProductBean> productlist()
	{
		Connection con=ConnectionManager.getConnection();
		System.out.println("List of products");
		//PreparedStatement stmt = null;
		PreparedStatement stmt1=null;
		ArrayList<ProductBean> holdingsList =new ArrayList<ProductBean>();
		String display="select * from product order by productid";
				ResultSet resultset=null;	
		try{
			stmt1=con.prepareStatement(display);
			resultset = stmt1.executeQuery();
			
			while(resultset.next()) {
				ProductBean B = new ProductBean();
				
				B.setProductid(resultset.getInt(1));
				B.setName(resultset.getString(2));
				B.setPrice(resultset.getFloat(3));
				B.setKind(resultset.getString(4));
				B.setUsage(resultset.getInt(5));
				B.setSellerid(resultset.getInt(6));
				
				holdingsList.add(B);
						
			}
			
		}
		catch(Exception e)
		{e.printStackTrace();
		}
		return holdingsList;


		
	}
	
	public ArrayList<orderBean> orderlist()
	{
		Connection con=ConnectionManager.getConnection();
		System.out.println("List of products");
		//PreparedStatement stmt = null;
		PreparedStatement stmt1=null;
		ArrayList<orderBean> holdingsList =new ArrayList<orderBean>();
		String display="select * from orders order by productid";
				ResultSet resultset=null;	
		try{
			stmt1=con.prepareStatement(display);
			resultset = stmt1.executeQuery();
			
			while(resultset.next()) {
				orderBean B = new orderBean();
				
				B.setPid(resultset.getInt(1));
				B.setPname(resultset.getString(2));
				B.setPrice(resultset.getFloat(3));
				B.setCid(resultset.getInt(4));
				B.setKind(resultset.getString(5));
				B.setUsage(resultset.getInt(6));
				B.setSellerid(resultset.getInt(7));
				
				holdingsList.add(B);
						
			}
			
		}
		catch(Exception e)
		{e.printStackTrace();
		}
		return holdingsList;
	}
	

}
