package user_login;
import java.sql.*;
import java.sql.PreparedStatement;

import shopping.*;
public class loginDao {
	private int uid;
	private String pwd;
	private String email;
	private String address;
	
	public boolean signin(int userid,String password)
	{
		Connection con=ConnectionManager.getConnection();
		String str="select * from userlogin where userid=? and password=?";
		ResultSet resultset=null;
		PreparedStatement stmt=null;
		boolean str1=true;
		try
		{
			stmt=con.prepareStatement(str);
			stmt.setInt(1, userid);
			stmt.setString(2, password);
			resultset=stmt.executeQuery();
			while(resultset.next())
			{
				uid=resultset.getInt(1);
			}
			if(uid==0)
			{
				
				str1=true;
			}
			else
				str1=false;
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		/*finally{

            try {

                    if(resultset != null)

                    resultset.close();

                    if(stmt != null)                                        

                    stmt.close();                           

                    con.commit();

                    if(con != null)

                    con.close();

            }catch (SQLException e) {

                    // TODO Auto-generated catch block

                    e.printStackTrace();

            }}*/


		return str1;
		/*while(resultset.next())
			{
				if(password.equals(resultset.getString(1)))
				{
					str1 = false;
				}
				else{
					str1 = true;
				}
			}*/
		
	}
	public boolean register(int userid,String password,String mailid,String address,String phoneno) 
	{Connection con=ConnectionManager.getConnection();
	String str1="insert into userlogin values(?,?,?,?,?)";
	String str2="select * from userlogin where userid=? ";
	ResultSet rs=null;
	PreparedStatement stmt=null;
	
	
	try
	{
		stmt=con.prepareStatement(str2);
		stmt.setInt(1,userid);
	
		rs=stmt.executeQuery();
		while(rs.next())
		{
			uid=rs.getInt(1);
		
			
		}
		if(uid!=0)
		{
			//System.out.println("userid exist.\nEnter another userid");
			return true;
		}
		else
		{
			stmt=con.prepareStatement(str1);
			stmt.setInt(1, userid);
			stmt.setString(2, password);
			stmt.setString(3,address);
			stmt.setString(4,mailid);
			stmt.setString(5,phoneno);
			stmt.executeUpdate();
			//System.out.println("Registered Successfully");
			
		}
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}
	finally{

        try {

                if(rs != null)

                rs.close();

                if(stmt != null)                                        

                stmt.close();                           

                con.commit();

                if(con != null)

                con.close();

        }catch (SQLException e) {

                // TODO Auto-generated catch block

                e.printStackTrace();

        }}


	return false;
	}

}
