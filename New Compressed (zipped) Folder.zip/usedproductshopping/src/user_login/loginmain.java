package user_login;

import java.sql.SQLException;
import java.util.Scanner;

import Sellandbuy.*;

import com.product.*;


public class loginmain {
	public static void main(String args[]) 
	{
		int login;
		String password,mailid,cf,address,phone;
		boolean condition=false;
		boolean switc=false;
		Scanner s=new Scanner(System.in);
		loginDao l=new loginDao();
		System.out.println("Welcome");
		do{
			switc=false;
		System.out.println("1)login\n2)register");
		int n=s.nextInt();
		s.nextLine();
		switch(n)
		{
		case 1: 
			System.out.println("userid");
			login=s.nextInt();
			System.out.println("password");
			s.nextLine();
			password=s.nextLine();
			switc=l.signin(login,password);
			{
				if(switc==true)
				System.out.println("enter the valid username and password");
				else
				{
					SellAndBuy sab=new SellAndBuy();
					sab.sellbuyview(login);
				}
			}
			break;
		case 2:do{
			switc=false;
			System.out.println("Enter your details\n userid");
			login=s.nextInt();
			System.out.println("enter your mailid");
			s.nextLine();
			mailid=s.nextLine();
			System.out.println("enter your address");
			address=s.nextLine();
			do
			{condition=false;
			System.out.println("enter your password");
			password=s.nextLine();
			System.out.println("conform your password");
			cf=s.nextLine();
					if(cf.equals(password))
						System.out.println("thank you entering the correct password");
					else
						{System.out.println("password mismatch " );
						condition=true;
						}
					System.out.println("phoneno");
					phone=s.nextLine();
					
			}while(condition);
				switc=l.register(login,password,mailid,address,phone);
				if(switc==true)
				
				{
				System.out.println("user exist.Register again");switc=true;}
		}while(switc);
		switc=true;
				break;
		default:System.out.println("enter the correct value");
		switc=true; 
		break;
			
		}

	}while(switc);
	}
}
