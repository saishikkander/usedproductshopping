package shipment;
import java.text.SimpleDateFormat;
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;



import com.product.ProductBean;

import shopping.ConnectionManager;

public class shipmentDao {
	public List shipment(int pid,int cid)
	{
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		PreparedStatement stmt1=null;
		List<shipmentBean> ob1=new ArrayList<shipmentBean>();
		List<shipmentBean> ob2=new ArrayList<shipmentBean>();
		String str="select * from orders where productid = ?";
		String str1="insert into shipment values(?,?,?,?,?,?)";
		String str2="delete from orders where productid = ?";
		String add="select address from userlogin where userid=?";
		String print="select * from shipment where customerid = ?";
		
		
		ResultSet resultset=null;
		ResultSet rs=null;
		
		SimpleDateFormat sf=new SimpleDateFormat("dd-MM-yyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, 7); // Adding 5 days
		String delivery = sf.format(c.getTime());
		
		
		
		 /*Calendar today = Calendar.getInstance();

         today.clear(Calendar.HOUR); today.clear(Calendar.MINUTE); today.clear(Calendar.SECOND);

         Date todayDate = today.getTime();*/
         



		
		try
		{
			stmt=conn.prepareStatement(str);
			stmt.setInt(1,pid);
			
			resultset=stmt.executeQuery();
			
			stmt1=conn.prepareStatement(add);
			stmt1.setInt(1,cid);
			
			rs=stmt1.executeQuery();
			
			while(resultset.next()&&rs.next())
			{
				shipmentBean b=new shipmentBean();
				b.setProductid(resultset.getInt(1));
				b.setProductname(resultset.getString(2));
				b.setProductprice(resultset.getFloat(3));
				b.setAddress(rs.getString(1));
				b.setDate(delivery);		System.out.println(rs.getString(1));
				b.setCustid(cid);
				ob1.add(b);
			}
			Iterator<shipmentBean> itr =ob1.iterator(); 
			while(itr.hasNext()){

			shipmentBean Bean = itr.next();
			
			stmt=conn.prepareStatement(str1);
			stmt.setInt(1, Bean.getProductid());
			stmt.setString(2,Bean.getProductname());
			stmt.setFloat(3, Bean.getProductprice());
			stmt.setString(4, Bean.getAddress());
			stmt.setInt(5, Bean.getCustid());
			stmt.setString(6, Bean.getDate());}
			stmt.executeUpdate();
			stmt=conn.prepareStatement(str2);
			stmt.setInt(1,pid);
			stmt.executeUpdate();
			stmt=conn.prepareStatement(print);
			stmt.setInt(1,cid);
			resultset=stmt.executeQuery();
			while(resultset.next())
			{
				shipmentBean Bean1=new shipmentBean();
				Bean1.setProductid(resultset.getInt(1));
				Bean1.setProductname(resultset.getString(2));
				Bean1.setProductprice(resultset.getFloat(3));
				Bean1.setAddress(resultset.getString(4));
				Bean1.setCustid(cid);
				Bean1.setDate(resultset.getString(6));
				ob2.add(Bean1);
			}
			
			
			
			
		
		
		
	}
		catch(SQLException e)
        {
        	e.printStackTrace();
        }
		
		return ob2;
		/*finally{

	        try {

	                if(resultset != null)

	                resultset.close();

	                if(stmt != null)                                        

	                stmt.close();                           

	                conn.commit();

	                if(conn != null)

	                conn.close();

	        }
	        catch(SQLException e)
	        {
	        	e.printStackTrace();
	        }*/
		
}
public List shipaddress(int pid,int cid,String address)
{
	Connection conn = ConnectionManager.getConnection();
	PreparedStatement stmt = null;
	List<shipmentBean> ob1=new ArrayList<shipmentBean>();
	List<shipmentBean> ob2=new ArrayList<shipmentBean>();
	String str="select * from orders where productid = ?";
	String str1="insert into shipment values(?,?,?,?,?,?)";
	String str2="delete from orders where productid = ?";
	String print="select * from shipment where customerid=?";
	//String add="select address from product where productid=?";
	
	ResultSet resultset=null;
	ResultSet rs=null;
	
	SimpleDateFormat sf=new SimpleDateFormat("dd-MM-yyyy");
	Calendar c = Calendar.getInstance();
	c.setTime(new Date()); // Now use today date.
	c.add(Calendar.DATE, 7); // Adding 5 days
	String delivery = sf.format(c.getTime());
	
	try
	{
		stmt=conn.prepareStatement(str);
		stmt.setInt(1,pid);
		
		resultset=stmt.executeQuery();
		//stmt=conn.prepareStatement(add);
		//stmt.setInt(1,pid);
		
		//rs=stmt.executeQuery();
		while(resultset.next())
		{
			shipmentBean b=new shipmentBean();
			b.setProductid(resultset.getInt(1));
			b.setProductname(resultset.getString(2));
			b.setProductprice(resultset.getFloat(3));
			b.setAddress(address);
			b.setCustid(cid);
			b.setDate(delivery);
			ob1.add(b);
		}
		Iterator<shipmentBean> itr =ob1.iterator(); 
		 while(itr.hasNext()){

		shipmentBean Bean = itr.next();
			stmt=conn.prepareStatement(str1);
		stmt.setInt(1, Bean.getProductid());
		stmt.setString(2,Bean.getProductname());
		stmt.setFloat(3, Bean.getProductprice());
		stmt.setString(4, Bean.getAddress());
		stmt.setInt(5, Bean.getCustid());
		stmt.setString(6, Bean.getDate());
		 }
		stmt.executeUpdate();
		
		stmt=conn.prepareStatement(str2);
		stmt.setInt(1,pid);
		stmt.executeUpdate();
		
		stmt=conn.prepareStatement(print);
		stmt.setInt(1,cid);
		resultset=stmt.executeQuery();
		while(resultset.next())
		{
			shipmentBean Bean1=new shipmentBean();
			Bean1.setProductid(resultset.getInt(1));
			Bean1.setProductname(resultset.getString(2));
			Bean1.setProductprice(resultset.getFloat(3));
			Bean1.setAddress(resultset.getString(4));
			Bean1.setCustid(cid);
			Bean1.setDate(resultset.getString(6));
			ob2.add(Bean1);
		}
		
		
	
	
	
}
	catch(SQLException e)
    {
    	e.printStackTrace();
    }
	return ob2;
}
}
