

create table customer(userid int,username varchar(25),productid int,productrate int );
insert into customer values(1,'sai',14,70);
select * from customer;
update orders set kind='grinder'  where customer_id=1002
create schema sai;
set schema sai;
select * from customer;
create table product(productid int,productname varchar(30),price float,kind varchar(20),usageperiod int);
insert into product values(103,'Lg WashingMachine',12000,'Washing Machine',15);
select * from product;
create table orders(productid int,productname varchar(30),price float,customer_id int);
select*from orders;
delete  from orders where productid=102;
alter table orders add usage int;

create table userloginsai(userid int,password varchar(30),address varchar(40));
alter table userlogin add emailid varchar(30);
select * from userlogin ;

select * from userlogin where userid = 1010
delete from userlogin where emailid='sai@gmail.com'
alter table USERLOGIN add phoneno varchar(30);
delete from
update USERLOGIN set phoneno='9009076854' where userid=1001
ALTER TABLE userlogin DROP COLUMN phoneno;

insert into userloginsai values(1002,'password','dfjasj');
select * from product where productname like 'M%';
alter table ORDERS add seller_id int;
update ORDERS SET SELLER_ID=1001 WHERE PRODUCTID between 101 and  120 
ALTER TABLE orders DROP COLUMN seller_id
select * from product
update product set seller_id=1002 where productid between 100 and 104
create table shipment (productid int,productname varchar(30),price float,address varchar(50));
alter table shipment add customerid int;
select * from shipment;
delete from SHIPMENT where productid=0
update shipment set address='indiranagar' where productid=100
create table adminlogin(name varchar(30),password varchar(30))
insert into ADMIN_LOGIN values('sai','password');
ALTER TABLE images ADD primary KEY (productid);
ALTER TABLE images ALTER COLUMN productid NOT NULL;
delete from product where productid=167

select * from IMAGES





select * from shipment;
create table images(productid int,image clob);
create table T_XBBNHGM_ORDER(order_id int GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),user_id int,product_id int,quantity int not null,price int not null,sub_total_amount int not null,tax int,total_amount int not null,primary key (order_id,user_id,product_id),constraint cust_fk foreign key (user_id) references T_XBBNHGM_USERS(user_id),constraint prod_fk foreign key (product_id) references T_XBBNHGM_PRODUCT(product_id));

